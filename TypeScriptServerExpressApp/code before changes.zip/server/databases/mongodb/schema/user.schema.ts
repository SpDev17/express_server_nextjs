import { Schema, model } from 'mongoose';
import { IUser } from '../model/user.model';
const schema = new Schema<IUser>({
    name: String,
    title: String,
    first_name: String,
    last_name: String,
    mobile: Number,
    alternate_contact_no: String,
    email: {
        type: String,
        lowercase: true,
        required: true
    },
    isactive: Boolean,
    groups: [],
    password: String,
    provider: String,
    salt: String,
    facebook: {},
    twitter: {},
    google: {},
    github: {},
    createdby: {},
    modifiedby: {},
    created: Date,
    modified: Date
});

export default model<IUser>('user', schema);