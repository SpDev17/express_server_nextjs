import { Express } from 'express';
import mongooseConnect from '../databases/mongodb/mongodb';
import { cliLoggerService } from '../services/logger/cli-logger.service';
import { ErrorMessages } from '../shared/enums/messages/error-messages.enum';
import { InfoMessages } from '../shared/enums/messages/info-messages.enum';
import { SpecialMessages } from '../shared/enums/messages/special-messages.enum';
import { exceptionLogWrapper } from '../shared/helpers/exception-log-wrapper.helper';
const { APP_PORT } = require('./envconfig');
const appSetup = async (app: Express) => {
    try {
        await Promise.all([
            mongooseConnect()
        ]);

        //console.log('Databases connected successfully!');
        //const APP_PORT = process.env.APP_PORT;
        cliLoggerService.info(InfoMessages.DatabasesConnected);
        cliLoggerService.info(SpecialMessages.DottedLine);

        app.listen(APP_PORT, () => {
            //console.log(`Server started on port ${APP_PORT}`);
            cliLoggerService.info(`Server started on port ${APP_PORT} 🚀🚀🚀`);
        });

    } catch (error: unknown) {
        //console.log('Unable to start the app!');
        //console.error(error);
        exceptionLogWrapper(error, ErrorMessages.AppStartupFail);
    }
};
export default appSetup;