const dotenv = require('dotenv');
dotenv.config();
module.exports = {
    APP_PORT: process.env.APP_PORT,
    MONGODB_URI: process.env.MONGODB_URI,
    npm_package_version: process.env.npm_package_version,
    LogToDb: process.env.LogToDb
};