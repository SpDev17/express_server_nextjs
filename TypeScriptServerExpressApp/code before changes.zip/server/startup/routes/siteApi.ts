import { Express, Request, Response } from 'express';
const siteApiRoute = (app: Express) => {
    //app.route('/user/me').get()
}

export default siteApiRoute;