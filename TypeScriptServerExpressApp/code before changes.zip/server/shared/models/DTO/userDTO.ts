import { IUser } from '../../../databases/mongodb/model/user.model';

export class UserResponseDTO {
    id!: string;
    first_name!: string;
    email!: string;

    static toResponse(user: IUser): UserResponseDTO {
        const userDTO = new UserResponseDTO();
        userDTO.id = user._id as string;
        userDTO.first_name = user.first_name as string;
        userDTO.email = user.email as string;
        return userDTO;
    }
}