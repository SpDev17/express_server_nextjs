export enum HTTPHeaders {
    ResponseTime = 'x-response-time',
    ForwardedFor = 'x-forwarded-for',
  }