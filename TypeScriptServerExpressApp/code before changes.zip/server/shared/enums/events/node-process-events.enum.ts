export enum NodeProcessEvents {
    UncaughtException = 'uncaughtException',
    UnhandledRejection = 'unhandledRejection'
}